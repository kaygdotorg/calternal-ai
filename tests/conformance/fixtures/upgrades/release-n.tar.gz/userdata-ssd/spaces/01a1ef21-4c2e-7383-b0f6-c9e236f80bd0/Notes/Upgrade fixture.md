---
calternal-id: 01a1ef21-4c40-707c-b636-bcbd81577a60
format: calternal-note/v1
---
# Upgrade fixture

Saved before the service handoff.

A subsequent saved revision.
