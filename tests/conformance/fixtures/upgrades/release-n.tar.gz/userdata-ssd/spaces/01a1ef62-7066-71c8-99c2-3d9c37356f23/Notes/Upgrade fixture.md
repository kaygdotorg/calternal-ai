---
calternal-id: 01a1ef62-7074-72c4-b26b-2d1c9debb370
format: calternal-note/v1
---
# Upgrade fixture

Saved before the service handoff.

A subsequent saved revision.
